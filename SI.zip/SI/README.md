# SmartChain AI - Inventory Management System

A comprehensive SaaS inventory management system with AI-powered chatbot capabilities, featuring both traditional Flask web interface and modern React frontend.

## 🚀 Features

### Core Functionality
- **Complete Inventory Management**: Add, edit, delete, and track inventory items
- **Advanced Dashboard**: Real-time statistics and interactive charts
- **CSV Data Import**: Bulk upload sales data and inventory updates
- **AI-Powered Chatbot**: Intelligent assistant for inventory queries
- **User Authentication**: Secure login and registration system
- **RESTful API**: Complete API endpoints for external integrations

### Dual Frontend Experience
- **Traditional Web Interface**: Server-side rendered Flask templates with Bootstrap
- **Modern React SPA**: Client-side React application with Tailwind CSS
- **Responsive Design**: Mobile-friendly interface for all devices
- **Dark Theme**: Professional dark mode across all interfaces

## 🛠️ Technology Stack

### Backend
- **Framework**: Flask with SQLAlchemy ORM
- **Database**: PostgreSQL with connection pooling
- **Authentication**: JWT tokens + Session-based auth
- **API**: RESTful endpoints with CORS support
- **File Processing**: Pandas for CSV data handling

### Frontend
- **React**: Modern React 18 with hooks
- **Styling**: Tailwind CSS with custom dark theme
- **Build Tool**: Vite for fast development
- **Charts**: Recharts for data visualization
- **Icons**: Lucide React for consistent iconography
- **HTTP Client**: Axios for API requests

### Legacy Frontend
- **Templates**: Jinja2 with Bootstrap 5
- **JavaScript**: Vanilla JS with modular architecture
- **Charts**: Chart.js for dashboard visualizations
- **Icons**: Feather icons

## 📦 Installation & Setup

### Prerequisites
- Python 3.8+
- Node.js 16+
- PostgreSQL database

### Backend Setup
1. Clone the repository:
   ```bash
   git clone https://github.com/Savan54321/SmartChainIntelligence.git
   cd SmartChainIntelligence
   ```

2. Install Python dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Set up environment variables:
   ```bash
   export DATABASE_URL="postgresql://user:password@localhost/smartchain_db"
   export SESSION_SECRET="your-secret-key"
   export JWT_SECRET="your-jwt-secret"
   ```

4. Initialize the database:
   ```bash
   python seed_data.py
   ```

5. Start the Flask server:
   ```bash
   python main.py
   ```

### React Frontend Setup
1. Navigate to the frontend directory:
   ```bash
   cd frontend
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the development server:
   ```bash
   npm run dev
   ```

## 🔧 Usage

### Web Interface
- Access the Flask interface at `http://localhost:5000`
- Login with: `admin@smartchainai.com` / `admin123`

### React Frontend
- Access the React app at `http://localhost:3000`
- Uses the same authentication as the Flask backend

### API Endpoints
- `POST /api/auth/login` - User authentication
- `GET /api/inventory` - Get all inventory items
- `POST /api/inventory` - Add new inventory item
- `PUT /api/inventory/:id` - Update inventory item
- `DELETE /api/inventory/:id` - Delete inventory item
- `GET /api/inventory/stats` - Get dashboard statistics
- `POST /api/upload-sales` - Upload CSV sales data
- `POST /api/chat` - AI chatbot interaction

## 📊 Database Schema

### Tables
- **users**: User authentication and profiles
- **inventory**: Product inventory with SKU, pricing, quantities
- **sales_records**: Sales transaction history
- **chat_messages**: AI chatbot conversation history

## 🤖 AI Features

The system includes an intelligent chatbot that can:
- Answer inventory-related questions
- Provide stock level information
- Suggest reorder recommendations
- Generate sales reports
- Help with general inventory management tasks

## 🔒 Security

- JWT-based authentication for API access
- Session-based authentication for web interface
- Password hashing with Werkzeug
- CORS configuration for API security
- Input validation and sanitization

## 🚀 Deployment

### Production Deployment
1. Set up PostgreSQL database
2. Configure environment variables
3. Install dependencies
4. Run database migrations
5. Start with Gunicorn: `gunicorn main:app`

### Docker Deployment
```bash
docker build -t smartchain-ai .
docker run -p 5000:5000 smartchain-ai
```

## 📈 Architecture

The system follows a modern full-stack architecture:

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   React SPA     │    │   Flask Web     │    │   PostgreSQL    │
│  (Frontend)     │◄──►│   (Backend)     │◄──►│   (Database)    │
│  Port: 3000     │    │   Port: 5000    │    │   Port: 5432    │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                              │
                              ▼
                       ┌─────────────────┐
                       │   RESTful API   │
                       │  (JWT + CORS)   │
                       └─────────────────┘
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 👥 Team

- **Developer**: SmartChain AI Team
- **Contact**: admin@smartchainai.com

## 🙏 Acknowledgments

- Flask community for the excellent web framework
- React team for the modern frontend library
- PostgreSQL for the robust database system
- All contributors and users of the system

---

**SmartChain AI** - Making inventory management intelligent and efficient.