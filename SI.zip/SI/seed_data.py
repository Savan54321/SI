"""
Seed script to populate the database with sample data
"""
import sys
import os

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import app, db
from models import User, InventoryItem, SalesRecord
from datetime import datetime, timedelta

def seed_database():
    with app.app_context():
        # Create a test user
        test_user = User.query.filter_by(email='admin@smartchainai.com').first()
        if not test_user:
            test_user = User(
                email='admin@smartchainai.com',
                first_name='Admin',
                last_name='User'
            )
            test_user.set_password('admin123')
            db.session.add(test_user)
            print("Created test user: admin@smartchainai.com / admin123")
        
        # Create sample inventory items
        sample_items = [
            {
                'name': 'Classic T-Shirt',
                'sku': 'TSHIRT-001',
                'description': 'Comfortable cotton t-shirt',
                'category': 'Apparel',
                'quantity': 50,
                'unit_price': 29.99,
                'reorder_level': 20,
                'supplier': 'Fashion Co.'
            },
            {
                'name': 'Denim Jeans',
                'sku': 'JEANS-002',
                'description': 'Classic blue denim jeans',
                'category': 'Apparel',
                'quantity': 15,
                'unit_price': 79.99,
                'reorder_level': 10,
                'supplier': 'Denim Works'
            },
            {
                'name': 'Wireless Headphones',
                'sku': 'HEADPHONES-003',
                'description': 'Bluetooth wireless headphones',
                'category': 'Electronics',
                'quantity': 8,
                'unit_price': 149.99,
                'reorder_level': 15,
                'supplier': 'Tech Solutions'
            },
            {
                'name': 'Coffee Mug',
                'sku': 'MUG-004',
                'description': 'Ceramic coffee mug',
                'category': 'Home & Kitchen',
                'quantity': 100,
                'unit_price': 12.99,
                'reorder_level': 25,
                'supplier': 'Kitchen Essentials'
            },
            {
                'name': 'Smartphone Case',
                'sku': 'CASE-005',
                'description': 'Protective smartphone case',
                'category': 'Electronics',
                'quantity': 5,
                'unit_price': 24.99,
                'reorder_level': 20,
                'supplier': 'Mobile Accessories'
            },
            {
                'name': 'Notebook',
                'sku': 'NOTEBOOK-006',
                'description': 'Spiral-bound notebook',
                'category': 'Office',
                'quantity': 75,
                'unit_price': 8.99,
                'reorder_level': 30,
                'supplier': 'Office Depot'
            }
        ]
        
        for item_data in sample_items:
            existing_item = InventoryItem.query.filter_by(sku=item_data['sku']).first()
            if not existing_item:
                item = InventoryItem(**item_data)
                db.session.add(item)
                print(f"Added inventory item: {item_data['name']}")
        
        # Create sample sales records
        items = InventoryItem.query.all()
        if items:
            for i, item in enumerate(items[:3]):  # Add sales for first 3 items
                sale_date = datetime.now() - timedelta(days=i+1)
                sale = SalesRecord(
                    item_id=item.id,
                    quantity_sold=5,
                    sale_price=item.unit_price,
                    sale_date=sale_date,
                    customer_name=f'Customer {i+1}',
                    notes='Sample sale'
                )
                db.session.add(sale)
                print(f"Added sale record for {item.name}")
        
        db.session.commit()
        print("Database seeded successfully!")

if __name__ == "__main__":
    seed_database()