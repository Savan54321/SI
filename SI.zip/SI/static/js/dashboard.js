// Dashboard-specific JavaScript functionality

let categoryChart = null;
let salesChart = null;

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeDashboard();
});

function initializeDashboard() {
    // Load dashboard data
    loadDashboardStats();
    
    // Set up refresh functionality
    setupRefreshButton();
    
    // Initialize charts
    initializeCharts();
    
    // Load low stock alerts
    loadLowStockAlerts();
}

function loadDashboardStats() {
    Utils.apiRequest('/api/inventory/stats')
        .then(data => {
            updateCharts(data);
            updateLowStockAlerts(data.low_stock_items);
        })
        .catch(error => {
            console.error('Error loading dashboard stats:', error);
            Utils.showToast('Failed to load dashboard data', 'danger');
        });
}

function initializeCharts() {
    // Initialize category chart
    const categoryCtx = document.getElementById('categoryChart');
    if (categoryCtx) {
        categoryChart = new Chart(categoryCtx, {
            type: 'doughnut',
            data: {
                labels: [],
                datasets: [{
                    data: [],
                    backgroundColor: [
                        '#0d6efd',
                        '#6c757d',
                        '#198754',
                        '#ffc107',
                        '#dc3545',
                        '#0dcaf0',
                        '#6f42c1',
                        '#fd7e14'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true
                        }
                    }
                }
            }
        });
    }
    
    // Initialize sales chart
    const salesCtx = document.getElementById('salesChart');
    if (salesCtx) {
        salesChart = new Chart(salesCtx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Sales',
                    data: [],
                    borderColor: '#0d6efd',
                    backgroundColor: 'rgba(13, 110, 253, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return Utils.formatNumber(value);
                            }
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return `Sales: ${Utils.formatNumber(context.parsed.y)}`;
                            }
                        }
                    }
                }
            }
        });
    }
}

function updateCharts(data) {
    // Update category chart
    if (categoryChart && data.category_stats) {
        const categories = data.category_stats.map(item => item.category || 'Uncategorized');
        const counts = data.category_stats.map(item => item.count);
        
        categoryChart.data.labels = categories;
        categoryChart.data.datasets[0].data = counts;
        categoryChart.update();
    }
    
    // Update sales chart
    if (salesChart && data.recent_sales) {
        const dates = data.recent_sales.map(item => Utils.formatDate(item.date, { month: 'short', day: 'numeric' }));
        const sales = data.recent_sales.map(item => item.total_sold);
        
        salesChart.data.labels = dates.reverse();
        salesChart.data.datasets[0].data = sales.reverse();
        salesChart.update();
    }
}

function loadLowStockAlerts() {
    const alertsContainer = document.getElementById('lowStockAlerts');
    if (!alertsContainer) return;
    
    Utils.apiRequest('/api/inventory/stats')
        .then(data => {
            updateLowStockAlerts(data.low_stock_items);
        })
        .catch(error => {
            console.error('Error loading low stock alerts:', error);
            alertsContainer.innerHTML = '<div class="alert alert-danger">Failed to load low stock alerts</div>';
        });
}

function updateLowStockAlerts(lowStockItems) {
    const alertsContainer = document.getElementById('lowStockAlerts');
    if (!alertsContainer) return;
    
    if (!lowStockItems || lowStockItems.length === 0) {
        alertsContainer.innerHTML = `
            <div class="text-center text-muted">
                <i data-feather="check-circle" class="mb-2" style="width: 32px; height: 32px;"></i>
                <p class="mb-0">No low stock items!</p>
            </div>
        `;
        feather.replace();
        return;
    }
    
    const alertsHTML = lowStockItems.slice(0, 5).map(item => `
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <i data-feather="alert-triangle" class="me-2"></i>
            <strong>${item.name}</strong> is low in stock (${item.quantity} units)
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `).join('');
    
    alertsContainer.innerHTML = alertsHTML;
    
    if (lowStockItems.length > 5) {
        alertsContainer.innerHTML += `
            <div class="text-center">
                <small class="text-muted">
                    and ${lowStockItems.length - 5} more items...
                    <a href="/inventory" class="text-decoration-none">View all</a>
                </small>
            </div>
        `;
    }
    
    feather.replace();
}

function setupRefreshButton() {
    // Add refresh functionality to any refresh buttons
    const refreshButtons = document.querySelectorAll('[onclick="refreshDashboard()"]');
    refreshButtons.forEach(button => {
        button.addEventListener('click', function() {
            refreshDashboard();
        });
    });
}

function refreshDashboard() {
    const refreshBtn = document.querySelector('[onclick="refreshDashboard()"]');
    let resetLoading = null;
    
    if (refreshBtn) {
        resetLoading = Utils.showLoading(refreshBtn, 'Refreshing...');
    }
    
    Utils.showToast('Refreshing dashboard data...', 'info');
    
    // Reload dashboard data
    loadDashboardStats();
    
    // Reset button state after a delay
    setTimeout(() => {
        if (resetLoading) {
            resetLoading();
        }
        Utils.showToast('Dashboard refreshed successfully!', 'success');
    }, 2000);
}

// Export functions for global use
window.refreshDashboard = refreshDashboard;
