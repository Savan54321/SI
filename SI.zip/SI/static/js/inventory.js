// Inventory management JavaScript functionality

let inventoryData = [];
let filteredData = [];

// Initialize inventory page
document.addEventListener('DOMContentLoaded', function() {
    initializeInventoryPage();
});

function initializeInventoryPage() {
    // Load inventory data
    loadInventoryData();
    
    // Initialize search and filters
    initializeSearch();
    initializeFilters();
    
    // Initialize modals
    initializeModals();
    
    // Initialize tooltips
    initializeTooltips();
}

function loadInventoryData() {
    // Get data from the table (server-rendered)
    const tableRows = document.querySelectorAll('#inventoryTable tbody tr');
    inventoryData = [];
    
    tableRows.forEach(row => {
        const cells = row.querySelectorAll('td');
        if (cells.length > 0) {
            inventoryData.push({
                element: row,
                name: cells[0].textContent.trim(),
                sku: cells[1].textContent.trim(),
                category: cells[2].textContent.trim(),
                quantity: parseInt(cells[3].textContent.trim()) || 0,
                price: parseFloat(cells[4].textContent.replace('$', '')) || 0,
                stockStatus: row.dataset.stockStatus || 'in_stock'
            });
        }
    });
    
    filteredData = [...inventoryData];
    populateFilters();
}

function initializeSearch() {
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', Utils.debounce(function() {
            filterInventory();
        }, 300));
    }
}

function initializeFilters() {
    const categoryFilter = document.getElementById('categoryFilter');
    const stockFilter = document.getElementById('stockFilter');
    
    if (categoryFilter) {
        categoryFilter.addEventListener('change', filterInventory);
    }
    
    if (stockFilter) {
        stockFilter.addEventListener('change', filterInventory);
    }
}

function populateFilters() {
    const categoryFilter = document.getElementById('categoryFilter');
    if (categoryFilter) {
        const categories = [...new Set(inventoryData.map(item => item.category).filter(cat => cat !== '-'))];
        
        categories.forEach(category => {
            const option = document.createElement('option');
            option.value = category;
            option.textContent = category;
            categoryFilter.appendChild(option);
        });
    }
}

function filterInventory() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const categoryFilter = document.getElementById('categoryFilter').value;
    const stockFilter = document.getElementById('stockFilter').value;
    
    filteredData = inventoryData.filter(item => {
        const matchesSearch = item.name.toLowerCase().includes(searchTerm) || 
                             item.sku.toLowerCase().includes(searchTerm);
        
        const matchesCategory = !categoryFilter || item.category === categoryFilter;
        
        const matchesStock = !stockFilter || item.stockStatus === stockFilter;
        
        return matchesSearch && matchesCategory && matchesStock;
    });
    
    // Show/hide table rows
    inventoryData.forEach(item => {
        const shouldShow = filteredData.includes(item);
        item.element.style.display = shouldShow ? '' : 'none';
    });
    
    // Update results count
    updateResultsCount();
}

function updateResultsCount() {
    const totalItems = inventoryData.length;
    const visibleItems = filteredData.length;
    
    // You can add a results counter element if needed
    console.log(`Showing ${visibleItems} of ${totalItems} items`);
}

function initializeModals() {
    // Initialize edit modal
    const editModal = document.getElementById('editItemModal');
    if (editModal) {
        editModal.addEventListener('show.bs.modal', function(event) {
            // Reset form validation
            const form = editModal.querySelector('form');
            form.classList.remove('was-validated');
        });
    }
    
    // Initialize add modal
    const addModal = document.getElementById('addItemModal');
    if (addModal) {
        addModal.addEventListener('show.bs.modal', function(event) {
            // Reset form
            const form = addModal.querySelector('form');
            form.reset();
            form.classList.remove('was-validated');
        });
    }
}

function editItem(itemId) {
    // Get item data from the table row
    const row = document.querySelector(`tr[data-item-id="${itemId}"]`) || 
                document.querySelector(`button[onclick="editItem(${itemId})"]`).closest('tr');
    
    if (!row) {
        Utils.showToast('Item not found', 'danger');
        return;
    }
    
    const cells = row.querySelectorAll('td');
    
    // Populate edit form
    document.getElementById('edit_name').value = cells[0].querySelector('strong').textContent.trim();
    document.getElementById('edit_sku').value = cells[1].textContent.trim();
    document.getElementById('edit_category').value = cells[2].textContent.trim() === '-' ? '' : cells[2].textContent.trim();
    
    // Extract quantity from badge
    const quantityBadge = cells[3].querySelector('.badge');
    document.getElementById('edit_quantity').value = quantityBadge ? quantityBadge.textContent.trim() : '0';
    
    // Extract price
    const priceText = cells[4].textContent.replace('$', '');
    document.getElementById('edit_unit_price').value = priceText;
    
    // Set description if available
    const descriptionElement = cells[0].querySelector('small');
    document.getElementById('edit_description').value = descriptionElement ? descriptionElement.textContent.trim() : '';
    
    // Set default reorder level
    document.getElementById('edit_reorder_level').value = '10';
    
    // Set form action
    const form = document.getElementById('editItemForm');
    form.action = `/inventory/update/${itemId}`;
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('editItemModal'));
    modal.show();
}

function deleteItem(itemId, itemName) {
    if (confirm(`Are you sure you want to delete "${itemName}"? This action cannot be undone.`)) {
        // Create form and submit
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = `/inventory/delete/${itemId}`;
        form.style.display = 'none';
        
        document.body.appendChild(form);
        form.submit();
    }
}

function addInventoryItem() {
    const form = document.getElementById('addItemForm');
    if (form.checkValidity()) {
        const submitBtn = form.querySelector('button[type="submit"]');
        const resetLoading = Utils.showLoading(submitBtn, 'Adding Item...');
        
        // Form will be submitted normally
        // Reset loading state will be handled by page reload
    }
}

// SKU generator
function generateSKU() {
    const name = document.getElementById('name').value.toUpperCase();
    const category = document.getElementById('category').value.toUpperCase();
    
    let sku = '';
    
    if (category) {
        sku += category.substring(0, 3);
    }
    
    if (name) {
        sku += name.substring(0, 3);
    }
    
    // Add random number
    sku += Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    
    document.getElementById('sku').value = sku;
}

// Auto-generate SKU when name or category changes
document.addEventListener('DOMContentLoaded', function() {
    const nameInput = document.getElementById('name');
    const categoryInput = document.getElementById('category');
    
    if (nameInput && categoryInput) {
        nameInput.addEventListener('input', Utils.debounce(generateSKU, 500));
        categoryInput.addEventListener('input', Utils.debounce(generateSKU, 500));
    }
});

// Export functions for global use
window.editItem = editItem;
window.deleteItem = deleteItem;
window.addInventoryItem = addInventoryItem;
window.generateSKU = generateSKU;
