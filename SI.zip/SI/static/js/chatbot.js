// Chatbot functionality for AI assistant

let chatHistory = [];

// Initialize chatbot when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeChatbot();
});

function initializeChatbot() {
    // Initialize chat form
    const chatForm = document.getElementById('chatForm');
    if (chatForm) {
        chatForm.addEventListener('submit', handleChatSubmit);
    }
    
    // Initialize message input
    const messageInput = document.getElementById('messageInput');
    if (messageInput) {
        messageInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleChatSubmit(e);
            }
        });
        
        // Auto-focus on input
        messageInput.focus();
    }
    
    // Scroll to bottom of chat
    scrollToBottom();
}

function handleChatSubmit(event) {
    event.preventDefault();
    
    const messageInput = document.getElementById('messageInput');
    const message = messageInput.value.trim();
    
    if (!message) return;
    
    // Clear input
    messageInput.value = '';
    
    // Add user message to chat
    addMessageToChat(message, 'user');
    
    // Show typing indicator
    showTypingIndicator();
    
    // Send message to server
    sendMessageToServer(message);
}

function addMessageToChat(message, sender) {
    const chatMessages = document.getElementById('chatMessages');
    const messageElement = document.createElement('div');
    
    messageElement.className = `chat-message ${sender}-message`;
    
    if (sender === 'user') {
        messageElement.innerHTML = `
            <div class="d-flex align-items-start">
                <div class="chat-avatar me-3">
                    <i data-feather="user"></i>
                </div>
                <div class="chat-content">
                    <div class="chat-bubble user-bubble">
                        ${escapeHtml(message)}
                    </div>
                    <div class="chat-timestamp">
                        <small class="text-muted">${formatTimestamp(new Date())}</small>
                    </div>
                </div>
            </div>
        `;
    } else {
        messageElement.innerHTML = `
            <div class="d-flex align-items-start">
                <div class="chat-avatar me-3">
                    <i data-feather="cpu"></i>
                </div>
                <div class="chat-content">
                    <div class="chat-bubble assistant-bubble">
                        ${message}
                    </div>
                    <div class="chat-timestamp">
                        <small class="text-muted">${formatTimestamp(new Date())}</small>
                    </div>
                </div>
            </div>
        `;
    }
    
    chatMessages.appendChild(messageElement);
    
    // Replace feather icons
    feather.replace();
    
    // Scroll to bottom
    scrollToBottom();
    
    // Add to history
    chatHistory.push({ message, sender, timestamp: new Date() });
}

function showTypingIndicator() {
    const typingIndicator = document.getElementById('typingIndicator');
    if (typingIndicator) {
        typingIndicator.classList.remove('d-none');
        feather.replace();
    }
}

function hideTypingIndicator() {
    const typingIndicator = document.getElementById('typingIndicator');
    if (typingIndicator) {
        typingIndicator.classList.add('d-none');
    }
}

function sendMessageToServer(message) {
    const sendBtn = document.getElementById('sendBtn');
    const originalHTML = sendBtn.innerHTML;
    
    // Disable send button
    sendBtn.disabled = true;
    sendBtn.innerHTML = '<i data-feather="loader" class="spinner"></i>';
    feather.replace();
    
    // Add CSS for spinner animation
    const style = document.createElement('style');
    style.textContent = `
        .spinner {
            animation: spin 1s linear infinite;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    `;
    document.head.appendChild(style);
    
    Utils.apiRequest('/api/chat', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message: message })
    })
    .then(response => {
        hideTypingIndicator();
        addMessageToChat(response.reply, 'assistant');
    })
    .catch(error => {
        hideTypingIndicator();
        console.error('Chat error:', error);
        
        let errorMessage = 'Sorry, I encountered an error. Please try again.';
        if (error.message.includes('401')) {
            errorMessage = 'Your session has expired. Please log in again.';
        } else if (error.message.includes('500')) {
            errorMessage = 'Server error. Please try again later.';
        }
        
        addMessageToChat(errorMessage, 'assistant');
    })
    .finally(() => {
        // Re-enable send button
        sendBtn.disabled = false;
        sendBtn.innerHTML = originalHTML;
        feather.replace();
        
        // Remove spinner style
        style.remove();
        
        // Focus input
        document.getElementById('messageInput').focus();
    });
}

function askQuestion(question) {
    const messageInput = document.getElementById('messageInput');
    messageInput.value = question;
    
    // Trigger form submission
    const chatForm = document.getElementById('chatForm');
    chatForm.dispatchEvent(new Event('submit'));
}

function scrollToBottom() {
    const chatMessages = document.getElementById('chatMessages');
    if (chatMessages) {
        setTimeout(() => {
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }, 100);
    }
}

function formatTimestamp(date) {
    return date.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: true 
    });
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function clearChat() {
    const chatMessages = document.getElementById('chatMessages');
    
    // Keep only the welcome message
    const welcomeMessage = chatMessages.querySelector('.assistant-message');
    chatMessages.innerHTML = '';
    
    if (welcomeMessage) {
        chatMessages.appendChild(welcomeMessage);
    }
    
    // Clear history
    chatHistory = [];
    
    Utils.showToast('Chat cleared', 'info');
}

function exportChat() {
    if (chatHistory.length === 0) {
        Utils.showToast('No chat history to export', 'warning');
        return;
    }
    
    const chatData = chatHistory.map(entry => ({
        timestamp: entry.timestamp.toISOString(),
        sender: entry.sender,
        message: entry.message
    }));
    
    const blob = new Blob([JSON.stringify(chatData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `chat_history_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    
    URL.revokeObjectURL(url);
    Utils.showToast('Chat history exported', 'success');
}

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // Ctrl/Cmd + K to focus input
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        document.getElementById('messageInput').focus();
    }
    
    // Ctrl/Cmd + L to clear chat
    if ((e.ctrlKey || e.metaKey) && e.key === 'l') {
        e.preventDefault();
        clearChat();
    }
});

// Export functions for global use
window.askQuestion = askQuestion;
window.clearChat = clearChat;
window.exportChat = exportChat;
