# Contributing to SmartChain AI

Thank you for your interest in contributing to SmartChain AI! This document provides guidelines for contributing to the project.

## Getting Started

### Prerequisites
- Python 3.8+
- Node.js 16+
- PostgreSQL database
- Git

### Development Setup

1. Fork the repository
2. Clone your fork:
   ```bash
   git clone https://github.com/your-username/SmartChainIntelligence.git
   cd SmartChainIntelligence
   ```

3. Set up the backend:
   ```bash
   pip install -r requirements.txt
   ```

4. Set up the frontend:
   ```bash
   cd frontend
   npm install
   ```

5. Configure environment variables:
   ```bash
   export DATABASE_URL="postgresql://user:password@localhost/smartchain_db"
   export SESSION_SECRET="your-secret-key"
   export JWT_SECRET="your-jwt-secret"
   ```

## Development Workflow

### Backend Development
- Follow PEP 8 style guidelines
- Use Flask best practices
- Write comprehensive tests
- Document API endpoints

### Frontend Development
- Use React functional components with hooks
- Follow Tailwind CSS conventions
- Maintain responsive design
- Test across different browsers

### Database Changes
- Create migrations for schema changes
- Test migrations thoroughly
- Document database schema updates

## Code Style

### Python
- Follow PEP 8
- Use type hints where appropriate
- Write docstrings for functions and classes
- Use meaningful variable names

### JavaScript/React
- Use ES6+ features
- Follow React best practices
- Use functional components
- Write JSDoc comments

### CSS
- Use Tailwind CSS utilities
- Maintain consistent spacing
- Follow mobile-first approach

## Testing

### Backend Tests
```bash
python -m pytest tests/
```

### Frontend Tests
```bash
cd frontend
npm test
```

## Submitting Changes

1. Create a new branch:
   ```bash
   git checkout -b feature/your-feature-name
   ```

2. Make your changes
3. Write or update tests
4. Ensure all tests pass
5. Commit your changes:
   ```bash
   git commit -m "Add meaningful commit message"
   ```

6. Push to your fork:
   ```bash
   git push origin feature/your-feature-name
   ```

7. Create a pull request

## Pull Request Guidelines

- Provide a clear description of changes
- Reference relevant issues
- Include screenshots for UI changes
- Ensure all tests pass
- Update documentation if needed

## Bug Reports

When reporting bugs, please include:
- Clear description of the issue
- Steps to reproduce
- Expected vs actual behavior
- Environment details
- Screenshots if applicable

## Feature Requests

For new features:
- Describe the feature clearly
- Explain the use case
- Provide examples if possible
- Consider the impact on existing functionality

## Code Review Process

- All changes require review
- Address reviewer feedback
- Maintain code quality standards
- Update documentation as needed

## Community Guidelines

- Be respectful and inclusive
- Help others learn and grow
- Follow the code of conduct
- Collaborate constructively

## Questions?

If you have questions about contributing, please:
- Check existing issues and discussions
- Create a new issue for questions
- Contact the maintainers

Thank you for contributing to SmartChain AI!