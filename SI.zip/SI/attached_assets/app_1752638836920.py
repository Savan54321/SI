
from flask import Flask, jsonify, request
from flask_cors import CORS
import pandas as pd, os, psycopg2
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity

app = Flask(__name__)
CORS(app)

app.config['JWT_SECRET_KEY'] = os.getenv('JWT_SECRET', 'super-secret-key')
jwt = JWTManager(app)

DB = {
    'dbname': os.getenv('DB_NAME'),
    'user': os.getenv('DB_USER'),
    'password': os.getenv('DB_PASS'),
    'host': os.getenv('DB_HOST'),
    'port': os.getenv('DB_PORT', 5432)
}

def get_conn():
    return psycopg2.connect(**DB)

@app.post('/api/login')
def login():
    email = request.json.get('email')
    token = create_access_token(identity=email)
    return {'access_token': token}

@app.get('/api/inventory')
@jwt_required()
def inventory():
    conn = get_conn(); cur = conn.cursor()
    cur.execute('SELECT * FROM inventory ORDER BY date DESC LIMIT 100')
    rows = [dict(zip([c[0] for c in cur.description], r)) for r in cur.fetchall()]
    cur.close(); conn.close()
    return jsonify(rows)

@app.post('/api/upload-sales')
@jwt_required()
def upload_sales():
    file = request.files['file']
    df = pd.read_csv(file)
    return {'rows_received': len(df)}

@app.post('/api/chatbot')
@jwt_required()
def chatbot():
    q = request.json.get('message','').lower()
    if 'stock' in q:
        return {'reply': 'Current stock for Blue T-Shirt is 42 units.'}
    return {'reply': 'Ask me about stock or forecast.'}

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
