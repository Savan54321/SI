import { useState, useEffect, useRef } from 'react'
import { MessageCircle, Send, User, Bot, Zap, HelpCircle, Package, AlertTriangle, TrendingUp } from 'lucide-react'
import axios from 'axios'

export default function Chatbot() {
  const [messages, setMessages] = useState([
    {
      id: 1,
      text: "Hello! I'm your AI inventory assistant. I can help you with stock level inquiries, sales data analysis, low stock alerts, and general inventory questions. What would you like to know about your inventory?",
      sender: 'bot',
      timestamp: new Date()
    }
  ])
  const [inputMessage, setInputMessage] = useState('')
  const [isTyping, setIsTyping] = useState(false)
  const [loading, setLoading] = useState(false)
  const messagesEndRef = useRef(null)

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  const handleSendMessage = async (e) => {
    e.preventDefault()
    if (!inputMessage.trim() || loading) return

    const userMessage = {
      id: Date.now(),
      text: inputMessage,
      sender: 'user',
      timestamp: new Date()
    }

    setMessages(prev => [...prev, userMessage])
    setInputMessage('')
    setIsTyping(true)
    setLoading(true)

    try {
      const response = await axios.post('/api/chat', {
        message: inputMessage
      })

      const botMessage = {
        id: Date.now() + 1,
        text: response.data.reply,
        sender: 'bot',
        timestamp: new Date()
      }

      setMessages(prev => [...prev, botMessage])
    } catch (error) {
      console.error('Chat error:', error)
      
      const errorMessage = {
        id: Date.now() + 1,
        text: "Sorry, I encountered an error. Please try again.",
        sender: 'bot',
        timestamp: new Date()
      }

      setMessages(prev => [...prev, errorMessage])
    } finally {
      setIsTyping(false)
      setLoading(false)
    }
  }

  const askQuickQuestion = (question) => {
    setInputMessage(question)
    // Auto-submit the question
    setTimeout(() => {
      handleSendMessage({ preventDefault: () => {} })
    }, 100)
  }

  const formatTime = (timestamp) => {
    return timestamp.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit' 
    })
  }

  return (
    <div className="h-full flex flex-col">
      <div className="flex-1 flex flex-col max-w-4xl mx-auto w-full">
        {/* Header */}
        <div className="bg-gray-800 p-4 rounded-t-lg">
          <div className="flex items-center gap-3">
            <MessageCircle className="h-6 w-6 text-blue-500" />
            <div>
              <h1 className="text-xl font-bold text-white">AI Inventory Assistant</h1>
              <p className="text-sm text-gray-400">
                Ask me about your inventory, stock levels, sales data, or get help with your questions.
              </p>
            </div>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 bg-gray-900 p-4 overflow-y-auto max-h-96 min-h-96">
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`flex gap-3 max-w-xs lg:max-w-md ${
                  message.sender === 'user' ? 'flex-row-reverse' : 'flex-row'
                }`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                    message.sender === 'user' 
                      ? 'bg-blue-500 text-white' 
                      : 'bg-gray-700 text-gray-300'
                  }`}>
                    {message.sender === 'user' ? (
                      <User className="h-4 w-4" />
                    ) : (
                      <Bot className="h-4 w-4" />
                    )}
                  </div>
                  
                  <div className={`rounded-lg px-4 py-2 ${
                    message.sender === 'user' 
                      ? 'bg-blue-500 text-white' 
                      : 'bg-gray-700 text-gray-100'
                  }`}>
                    <p className="text-sm">{message.text}</p>
                    <p className="text-xs mt-1 opacity-75">
                      {formatTime(message.timestamp)}
                    </p>
                  </div>
                </div>
              </div>
            ))}
            
            {isTyping && (
              <div className="flex justify-start">
                <div className="flex gap-3 max-w-xs lg:max-w-md">
                  <div className="w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center flex-shrink-0">
                    <Bot className="h-4 w-4 text-gray-300" />
                  </div>
                  <div className="bg-gray-700 text-gray-100 rounded-lg px-4 py-2">
                    <div className="flex space-x-1">
                      <div className="w-1 h-1 bg-gray-400 rounded-full animate-bounce"></div>
                      <div className="w-1 h-1 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-1 h-1 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>
        </div>

        {/* Input */}
        <div className="bg-gray-800 p-4 rounded-b-lg">
          <form onSubmit={handleSendMessage} className="flex gap-2">
            <input
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder="Type your message..."
              className="input flex-1"
              disabled={loading}
            />
            <button
              type="submit"
              disabled={loading || !inputMessage.trim()}
              className="btn btn-primary p-2"
            >
              <Send className="h-5 w-5" />
            </button>
          </form>
        </div>
      </div>

      {/* Quick Questions */}
      <div className="mt-6 card p-6">
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <Zap className="h-5 w-5" />
          Quick Questions
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <button
            onClick={() => askQuickQuestion('What is my current stock status?')}
            className="btn btn-secondary flex items-center gap-2 justify-start"
          >
            <Package className="h-4 w-4" />
            Stock Status
          </button>
          
          <button
            onClick={() => askQuickQuestion('Which items are low in stock?')}
            className="btn btn-secondary flex items-center gap-2 justify-start"
          >
            <AlertTriangle className="h-4 w-4" />
            Low Stock Items
          </button>
          
          <button
            onClick={() => askQuickQuestion('What are my sales figures?')}
            className="btn btn-secondary flex items-center gap-2 justify-start"
          >
            <TrendingUp className="h-4 w-4" />
            Sales Data
          </button>
          
          <button
            onClick={() => askQuickQuestion('Help me with inventory management')}
            className="btn btn-secondary flex items-center gap-2 justify-start"
          >
            <HelpCircle className="h-4 w-4" />
            Get Help
          </button>
        </div>
      </div>
    </div>
  )
}