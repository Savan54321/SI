import { useState, useEffect } from 'react'
import { Package, Plus, Search, Edit, Trash2, Filter } from 'lucide-react'
import axios from 'axios'

export default function Inventory() {
  const [items, setItems] = useState([])
  const [filteredItems, setFilteredItems] = useState([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [categoryFilter, setCategoryFilter] = useState('')
  const [stockFilter, setStockFilter] = useState('')
  const [categories, setCategories] = useState([])
  const [showAddModal, setShowAddModal] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)
  const [selectedItem, setSelectedItem] = useState(null)
  const [formData, setFormData] = useState({
    name: '',
    sku: '',
    description: '',
    category: '',
    quantity: 0,
    unit_price: 0,
    reorder_level: 10,
    supplier: ''
  })

  useEffect(() => {
    loadInventoryData()
  }, [])

  useEffect(() => {
    filterItems()
  }, [items, searchTerm, categoryFilter, stockFilter])

  const loadInventoryData = async () => {
    try {
      const response = await axios.get('/api/inventory')
      setItems(response.data)
      
      // Extract unique categories
      const uniqueCategories = [...new Set(response.data.map(item => item.category).filter(Boolean))]
      setCategories(uniqueCategories)
    } catch (error) {
      console.error('Error loading inventory:', error)
    } finally {
      setLoading(false)
    }
  }

  const filterItems = () => {
    let filtered = items.filter(item => {
      const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          item.sku.toLowerCase().includes(searchTerm.toLowerCase())
      
      const matchesCategory = !categoryFilter || item.category === categoryFilter
      
      const matchesStock = !stockFilter || 
        (stockFilter === 'low' && item.quantity <= item.reorder_level) ||
        (stockFilter === 'out_of_stock' && item.quantity === 0) ||
        (stockFilter === 'in_stock' && item.quantity > item.reorder_level)
      
      return matchesSearch && matchesCategory && matchesStock
    })
    
    setFilteredItems(filtered)
  }

  const handleAddItem = async (e) => {
    e.preventDefault()
    try {
      await axios.post('/api/inventory', formData)
      setShowAddModal(false)
      setFormData({
        name: '',
        sku: '',
        description: '',
        category: '',
        quantity: 0,
        unit_price: 0,
        reorder_level: 10,
        supplier: ''
      })
      loadInventoryData()
    } catch (error) {
      console.error('Error adding item:', error)
    }
  }

  const handleUpdateItem = async (e) => {
    e.preventDefault()
    try {
      await axios.put(`/api/inventory/${selectedItem.id}`, formData)
      setShowEditModal(false)
      setSelectedItem(null)
      loadInventoryData()
    } catch (error) {
      console.error('Error updating item:', error)
    }
  }

  const handleDeleteItem = async (id, name) => {
    if (window.confirm(`Are you sure you want to delete "${name}"?`)) {
      try {
        await axios.delete(`/api/inventory/${id}`)
        loadInventoryData()
      } catch (error) {
        console.error('Error deleting item:', error)
      }
    }
  }

  const openEditModal = (item) => {
    setSelectedItem(item)
    setFormData({
      name: item.name,
      sku: item.sku,
      description: item.description || '',
      category: item.category || '',
      quantity: item.quantity,
      unit_price: item.unit_price,
      reorder_level: item.reorder_level,
      supplier: item.supplier || ''
    })
    setShowEditModal(true)
  }

  const getStatusBadge = (item) => {
    if (item.quantity === 0) {
      return <span className="px-2 py-1 text-xs bg-red-500 text-white rounded">Out of Stock</span>
    } else if (item.quantity <= item.reorder_level) {
      return <span className="px-2 py-1 text-xs bg-yellow-500 text-black rounded">Low Stock</span>
    } else {
      return <span className="px-2 py-1 text-xs bg-green-500 text-white rounded">In Stock</span>
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-white">Loading inventory...</div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-white">Inventory Management</h1>
        <button
          onClick={() => setShowAddModal(true)}
          className="btn btn-primary flex items-center gap-2"
        >
          <Plus className="h-4 w-4" />
          Add Item
        </button>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="relative">
          <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search items..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="input pl-10"
          />
        </div>
        
        <select
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
          className="input"
        >
          <option value="">All Categories</option>
          {categories.map(category => (
            <option key={category} value={category}>{category}</option>
          ))}
        </select>
        
        <select
          value={stockFilter}
          onChange={(e) => setStockFilter(e.target.value)}
          className="input"
        >
          <option value="">All Stock Levels</option>
          <option value="low">Low Stock</option>
          <option value="in_stock">In Stock</option>
          <option value="out_of_stock">Out of Stock</option>
        </select>
      </div>

      {/* Inventory Table */}
      <div className="card">
        <div className="overflow-x-auto">
          <table className="table">
            <thead>
              <tr>
                <th>Name</th>
                <th>SKU</th>
                <th>Category</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Total Value</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredItems.map((item) => (
                <tr key={item.id}>
                  <td>
                    <div>
                      <div className="font-medium text-white">{item.name}</div>
                      {item.description && (
                        <div className="text-sm text-gray-400">{item.description}</div>
                      )}
                    </div>
                  </td>
                  <td>
                    <code className="text-sm bg-gray-700 px-2 py-1 rounded">{item.sku}</code>
                  </td>
                  <td>{item.category || '-'}</td>
                  <td>
                    <span className={`px-2 py-1 text-xs rounded ${
                      item.quantity === 0 ? 'bg-red-500' :
                      item.quantity <= item.reorder_level ? 'bg-yellow-500 text-black' :
                      'bg-green-500'
                    }`}>
                      {item.quantity}
                    </span>
                  </td>
                  <td>${item.unit_price.toFixed(2)}</td>
                  <td>${(item.quantity * item.unit_price).toFixed(2)}</td>
                  <td>{getStatusBadge(item)}</td>
                  <td>
                    <div className="flex gap-2">
                      <button
                        onClick={() => openEditModal(item)}
                        className="p-1 text-blue-400 hover:text-blue-300"
                      >
                        <Edit className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteItem(item.id, item.name)}
                        className="p-1 text-red-400 hover:text-red-300"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        {filteredItems.length === 0 && (
          <div className="text-center py-8">
            <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-400">No inventory items found</p>
          </div>
        )}
      </div>

      {/* Add Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-gray-800 p-6 rounded-lg w-full max-w-md">
            <h3 className="text-lg font-semibold text-white mb-4">Add New Item</h3>
            <form onSubmit={handleAddItem} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="Name"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="input"
                  required
                />
                <input
                  type="text"
                  placeholder="SKU"
                  value={formData.sku}
                  onChange={(e) => setFormData({...formData, sku: e.target.value})}
                  className="input"
                  required
                />
              </div>
              
              <textarea
                placeholder="Description"
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                className="input h-20"
              />
              
              <div className="grid grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="Category"
                  value={formData.category}
                  onChange={(e) => setFormData({...formData, category: e.target.value})}
                  className="input"
                />
                <input
                  type="text"
                  placeholder="Supplier"
                  value={formData.supplier}
                  onChange={(e) => setFormData({...formData, supplier: e.target.value})}
                  className="input"
                />
              </div>
              
              <div className="grid grid-cols-3 gap-4">
                <input
                  type="number"
                  placeholder="Quantity"
                  value={formData.quantity}
                  onChange={(e) => setFormData({...formData, quantity: parseInt(e.target.value) || 0})}
                  className="input"
                  min="0"
                />
                <input
                  type="number"
                  placeholder="Unit Price"
                  value={formData.unit_price}
                  onChange={(e) => setFormData({...formData, unit_price: parseFloat(e.target.value) || 0})}
                  className="input"
                  min="0"
                  step="0.01"
                />
                <input
                  type="number"
                  placeholder="Reorder Level"
                  value={formData.reorder_level}
                  onChange={(e) => setFormData({...formData, reorder_level: parseInt(e.target.value) || 0})}
                  className="input"
                  min="0"
                />
              </div>
              
              <div className="flex gap-4">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="btn btn-secondary flex-1"
                >
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary flex-1">
                  Add Item
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Modal */}
      {showEditModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-gray-800 p-6 rounded-lg w-full max-w-md">
            <h3 className="text-lg font-semibold text-white mb-4">Edit Item</h3>
            <form onSubmit={handleUpdateItem} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="Name"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="input"
                  required
                />
                <input
                  type="text"
                  placeholder="SKU"
                  value={formData.sku}
                  onChange={(e) => setFormData({...formData, sku: e.target.value})}
                  className="input"
                  required
                  disabled
                />
              </div>
              
              <textarea
                placeholder="Description"
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                className="input h-20"
              />
              
              <div className="grid grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="Category"
                  value={formData.category}
                  onChange={(e) => setFormData({...formData, category: e.target.value})}
                  className="input"
                />
                <input
                  type="text"
                  placeholder="Supplier"
                  value={formData.supplier}
                  onChange={(e) => setFormData({...formData, supplier: e.target.value})}
                  className="input"
                />
              </div>
              
              <div className="grid grid-cols-3 gap-4">
                <input
                  type="number"
                  placeholder="Quantity"
                  value={formData.quantity}
                  onChange={(e) => setFormData({...formData, quantity: parseInt(e.target.value) || 0})}
                  className="input"
                  min="0"
                />
                <input
                  type="number"
                  placeholder="Unit Price"
                  value={formData.unit_price}
                  onChange={(e) => setFormData({...formData, unit_price: parseFloat(e.target.value) || 0})}
                  className="input"
                  min="0"
                  step="0.01"
                />
                <input
                  type="number"
                  placeholder="Reorder Level"
                  value={formData.reorder_level}
                  onChange={(e) => setFormData({...formData, reorder_level: parseInt(e.target.value) || 0})}
                  className="input"
                  min="0"
                />
              </div>
              
              <div className="flex gap-4">
                <button
                  type="button"
                  onClick={() => setShowEditModal(false)}
                  className="btn btn-secondary flex-1"
                >
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary flex-1">
                  Update Item
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}