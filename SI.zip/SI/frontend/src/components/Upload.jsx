import { useState } from 'react'
import { Upload as UploadIcon, Download, AlertCircle, CheckCircle } from 'lucide-react'
import axios from 'axios'

export default function Upload() {
  const [file, setFile] = useState(null)
  const [uploading, setUploading] = useState(false)
  const [uploadResult, setUploadResult] = useState(null)

  const handleFileSelect = (e) => {
    const selectedFile = e.target.files[0]
    if (selectedFile && selectedFile.type === 'text/csv') {
      setFile(selectedFile)
      setUploadResult(null)
    } else {
      alert('Please select a CSV file')
    }
  }

  const handleUpload = async () => {
    if (!file) return

    setUploading(true)
    const formData = new FormData()
    formData.append('file', file)

    try {
      const response = await axios.post('/api/upload-sales', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })
      
      setUploadResult({
        success: true,
        message: response.data.message || 'File uploaded successfully',
        details: response.data
      })
      setFile(null)
    } catch (error) {
      setUploadResult({
        success: false,
        message: error.response?.data?.message || 'Upload failed',
        details: error.response?.data
      })
    } finally {
      setUploading(false)
    }
  }

  const downloadTemplate = () => {
    const csvContent = "sku,quantity_sold,sale_price,sale_date,customer_name,notes\nSHIRT-001,5,29.99,2025-01-15,John Smith,Online order\nPANTS-002,2,49.99,2025-01-15,Jane Doe,Store purchase"
    
    const blob = new Blob([csvContent], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'sales_template.csv'
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white">Upload Sales Data</h1>

      {/* Upload Section */}
      <div className="card p-6">
        <div className="space-y-4">
          <div className="bg-blue-500 bg-opacity-10 border border-blue-500 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-blue-400 mt-0.5" />
              <div>
                <h3 className="font-semibold text-blue-400">CSV Format Requirements</h3>
                <ul className="mt-2 text-sm text-blue-300 space-y-1">
                  <li>• Required columns: sku, quantity_sold, sale_price, sale_date</li>
                  <li>• Optional columns: customer_name, notes</li>
                  <li>• Date format: YYYY-MM-DD or MM/DD/YYYY</li>
                  <li>• SKU must match existing inventory items</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex-1">
              <input
                type="file"
                accept=".csv"
                onChange={handleFileSelect}
                className="input"
              />
            </div>
            <button
              onClick={downloadTemplate}
              className="btn btn-secondary flex items-center gap-2"
            >
              <Download className="h-4 w-4" />
              Download Template
            </button>
          </div>

          {file && (
            <div className="bg-gray-700 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white font-medium">{file.name}</p>
                  <p className="text-sm text-gray-400">
                    {(file.size / 1024).toFixed(2)} KB
                  </p>
                </div>
                <button
                  onClick={handleUpload}
                  disabled={uploading}
                  className="btn btn-primary flex items-center gap-2"
                >
                  <UploadIcon className="h-4 w-4" />
                  {uploading ? 'Uploading...' : 'Upload File'}
                </button>
              </div>
            </div>
          )}

          {uploadResult && (
            <div className={`p-4 rounded-lg ${
              uploadResult.success 
                ? 'bg-green-500 bg-opacity-10 border border-green-500' 
                : 'bg-red-500 bg-opacity-10 border border-red-500'
            }`}>
              <div className="flex items-start gap-3">
                {uploadResult.success ? (
                  <CheckCircle className="h-5 w-5 text-green-400 mt-0.5" />
                ) : (
                  <AlertCircle className="h-5 w-5 text-red-400 mt-0.5" />
                )}
                <div>
                  <p className={`font-medium ${
                    uploadResult.success ? 'text-green-400' : 'text-red-400'
                  }`}>
                    {uploadResult.message}
                  </p>
                  {uploadResult.details && (
                    <pre className="mt-2 text-sm text-gray-300">
                      {JSON.stringify(uploadResult.details, null, 2)}
                    </pre>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Sample Format */}
      <div className="card p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Sample CSV Format</h3>
        <div className="overflow-x-auto">
          <table className="table">
            <thead>
              <tr>
                <th>sku</th>
                <th>quantity_sold</th>
                <th>sale_price</th>
                <th>sale_date</th>
                <th>customer_name</th>
                <th>notes</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>SHIRT-001</td>
                <td>5</td>
                <td>29.99</td>
                <td>2025-01-15</td>
                <td>John Smith</td>
                <td>Online order</td>
              </tr>
              <tr>
                <td>PANTS-002</td>
                <td>2</td>
                <td>49.99</td>
                <td>2025-01-15</td>
                <td>Jane Doe</td>
                <td>Store purchase</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Tips */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="card p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Best Practices</h3>
          <ul className="space-y-2 text-gray-300">
            <li className="flex items-start gap-2">
              <CheckCircle className="h-4 w-4 text-green-400 mt-0.5 flex-shrink-0" />
              Use consistent date formats
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle className="h-4 w-4 text-green-400 mt-0.5 flex-shrink-0" />
              Verify SKUs exist in inventory
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle className="h-4 w-4 text-green-400 mt-0.5 flex-shrink-0" />
              Include all required columns
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle className="h-4 w-4 text-green-400 mt-0.5 flex-shrink-0" />
              Test with small files first
            </li>
          </ul>
        </div>

        <div className="card p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Common Issues</h3>
          <ul className="space-y-2 text-gray-300">
            <li className="flex items-start gap-2">
              <AlertCircle className="h-4 w-4 text-red-400 mt-0.5 flex-shrink-0" />
              Missing required columns
            </li>
            <li className="flex items-start gap-2">
              <AlertCircle className="h-4 w-4 text-red-400 mt-0.5 flex-shrink-0" />
              Invalid date formats
            </li>
            <li className="flex items-start gap-2">
              <AlertCircle className="h-4 w-4 text-red-400 mt-0.5 flex-shrink-0" />
              Non-existent SKUs
            </li>
            <li className="flex items-start gap-2">
              <AlertCircle className="h-4 w-4 text-red-400 mt-0.5 flex-shrink-0" />
              Negative quantities
            </li>
          </ul>
        </div>
      </div>
    </div>
  )
}