import os
import pandas as pd
from datetime import datetime
from flask import render_template, request, jsonify, redirect, url_for, flash, session
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
from sqlalchemy import func, desc
from app import app, db
from models import User, InventoryItem, SalesRecord, ChatMessage

@app.route('/')
def index():
    """Landing page"""
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login page"""
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        if not email or not password:
            flash('Email and password are required', 'error')
            return render_template('login.html')
        
        user = User.query.filter_by(email=email).first()
        
        if user and user.check_password(password):
            session['user_id'] = user.id
            session['user_email'] = user.email
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid email or password', 'error')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    """Registration page"""
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        
        if not email or not password:
            flash('Email and password are required', 'error')
            return render_template('login.html')
        
        if User.query.filter_by(email=email).first():
            flash('Email already exists', 'error')
            return render_template('login.html')
        
        user = User(email=email, first_name=first_name, last_name=last_name)
        user.set_password(password)
        
        db.session.add(user)
        db.session.commit()
        
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    """Logout user"""
    session.clear()
    flash('You have been logged out', 'info')
    return redirect(url_for('index'))

def login_required(f):
    """Decorator to require login"""
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please login to access this page', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

@app.route('/dashboard')
@login_required
def dashboard():
    """Dashboard page"""
    # Get dashboard statistics
    total_items = InventoryItem.query.count()
    low_stock_items = InventoryItem.query.filter(
        InventoryItem.quantity <= InventoryItem.reorder_level
    ).count()
    total_sales = db.session.query(func.sum(SalesRecord.quantity_sold)).scalar() or 0
    total_revenue = db.session.query(func.sum(SalesRecord.sale_price * SalesRecord.quantity_sold)).scalar() or 0
    
    # Recent sales
    recent_sales = SalesRecord.query.order_by(desc(SalesRecord.sale_date)).limit(5).all()
    
    return render_template('dashboard.html', 
                         total_items=total_items,
                         low_stock_items=low_stock_items,
                         total_sales=total_sales,
                         total_revenue=float(total_revenue),
                         recent_sales=recent_sales)

@app.route('/inventory')
@login_required
def inventory():
    """Inventory management page"""
    items = InventoryItem.query.order_by(InventoryItem.name).all()
    return render_template('inventory.html', items=items)

@app.route('/inventory/add', methods=['POST'])
@login_required
def add_inventory_item():
    """Add new inventory item"""
    try:
        name = request.form.get('name')
        sku = request.form.get('sku')
        description = request.form.get('description')
        category = request.form.get('category')
        quantity = int(request.form.get('quantity', 0))
        unit_price = float(request.form.get('unit_price', 0))
        reorder_level = int(request.form.get('reorder_level', 10))
        supplier = request.form.get('supplier')
        
        if not name or not sku:
            flash('Name and SKU are required', 'error')
            return redirect(url_for('inventory'))
        
        # Check if SKU already exists
        if InventoryItem.query.filter_by(sku=sku).first():
            flash('SKU already exists', 'error')
            return redirect(url_for('inventory'))
        
        item = InventoryItem(
            name=name,
            sku=sku,
            description=description,
            category=category,
            quantity=quantity,
            unit_price=unit_price,
            reorder_level=reorder_level,
            supplier=supplier
        )
        
        db.session.add(item)
        db.session.commit()
        
        flash('Inventory item added successfully!', 'success')
    except Exception as e:
        flash(f'Error adding item: {str(e)}', 'error')
    
    return redirect(url_for('inventory'))

@app.route('/inventory/update/<int:item_id>', methods=['POST'])
@login_required
def update_inventory_item(item_id):
    """Update inventory item"""
    try:
        item = InventoryItem.query.get_or_404(item_id)
        
        item.name = request.form.get('name')
        item.description = request.form.get('description')
        item.category = request.form.get('category')
        item.quantity = int(request.form.get('quantity', 0))
        item.unit_price = float(request.form.get('unit_price', 0))
        item.reorder_level = int(request.form.get('reorder_level', 10))
        item.supplier = request.form.get('supplier')
        
        db.session.commit()
        flash('Inventory item updated successfully!', 'success')
    except Exception as e:
        flash(f'Error updating item: {str(e)}', 'error')
    
    return redirect(url_for('inventory'))

@app.route('/inventory/delete/<int:item_id>', methods=['POST'])
@login_required
def delete_inventory_item(item_id):
    """Delete inventory item"""
    try:
        item = InventoryItem.query.get_or_404(item_id)
        db.session.delete(item)
        db.session.commit()
        flash('Inventory item deleted successfully!', 'success')
    except Exception as e:
        flash(f'Error deleting item: {str(e)}', 'error')
    
    return redirect(url_for('inventory'))

@app.route('/upload')
@login_required
def upload_page():
    """Upload CSV page"""
    return render_template('upload.html')

@app.route('/upload/sales', methods=['POST'])
@login_required
def upload_sales():
    """Upload sales data from CSV"""
    try:
        if 'file' not in request.files:
            flash('No file selected', 'error')
            return redirect(url_for('upload_page'))
        
        file = request.files['file']
        if file.filename == '':
            flash('No file selected', 'error')
            return redirect(url_for('upload_page'))
        
        if not file.filename.endswith('.csv'):
            flash('Please upload a CSV file', 'error')
            return redirect(url_for('upload_page'))
        
        # Read CSV file
        df = pd.read_csv(file)
        
        # Validate required columns
        required_columns = ['sku', 'quantity_sold', 'sale_price', 'sale_date']
        if not all(col in df.columns for col in required_columns):
            flash(f'CSV must contain columns: {", ".join(required_columns)}', 'error')
            return redirect(url_for('upload_page'))
        
        successful_records = 0
        failed_records = 0
        
        for _, row in df.iterrows():
            try:
                # Find inventory item by SKU
                item = InventoryItem.query.filter_by(sku=row['sku']).first()
                if not item:
                    failed_records += 1
                    continue
                
                # Parse sale date
                sale_date = pd.to_datetime(row['sale_date'])
                
                # Create sales record
                sales_record = SalesRecord(
                    item_id=item.id,
                    quantity_sold=int(row['quantity_sold']),
                    sale_price=float(row['sale_price']),
                    sale_date=sale_date,
                    customer_name=row.get('customer_name', ''),
                    notes=row.get('notes', '')
                )
                
                db.session.add(sales_record)
                
                # Update inventory quantity
                item.quantity = max(0, item.quantity - int(row['quantity_sold']))
                
                successful_records += 1
                
            except Exception as e:
                failed_records += 1
                continue
        
        db.session.commit()
        
        flash(f'Successfully processed {successful_records} records. {failed_records} records failed.', 'success')
        
    except Exception as e:
        flash(f'Error processing file: {str(e)}', 'error')
    
    return redirect(url_for('upload_page'))

@app.route('/chatbot')
@login_required
def chatbot_page():
    """Chatbot page"""
    return render_template('chatbot.html')

@app.route('/api/chat', methods=['POST'])
@login_required
def chat():
    """Process chatbot messages"""
    try:
        message = request.json.get('message', '').lower().strip()
        
        if not message:
            return jsonify({'reply': 'Please enter a message.'})
        
        # Simple chatbot responses
        if 'stock' in message or 'inventory' in message:
            # Extract item name if possible
            words = message.split()
            item_name = None
            for i, word in enumerate(words):
                if word in ['stock', 'inventory'] and i + 1 < len(words):
                    item_name = ' '.join(words[i+1:])
                    break
            
            if item_name:
                # Search for item
                item = InventoryItem.query.filter(
                    InventoryItem.name.ilike(f'%{item_name}%')
                ).first()
                
                if item:
                    status = "Low Stock" if item.quantity <= item.reorder_level else "In Stock"
                    reply = f"Current stock for {item.name}: {item.quantity} units ({status})"
                else:
                    reply = f"Item '{item_name}' not found in inventory."
            else:
                # General stock info
                total_items = InventoryItem.query.count()
                low_stock = InventoryItem.query.filter(
                    InventoryItem.quantity <= InventoryItem.reorder_level
                ).count()
                reply = f"Total inventory items: {total_items}. Low stock items: {low_stock}"
        
        elif 'sales' in message or 'revenue' in message:
            total_sales = db.session.query(func.sum(SalesRecord.quantity_sold)).scalar() or 0
            total_revenue = db.session.query(func.sum(SalesRecord.sale_price * SalesRecord.quantity_sold)).scalar() or 0
            reply = f"Total sales: {total_sales} units. Total revenue: ${total_revenue:.2f}"
        
        elif 'low stock' in message or 'reorder' in message:
            low_stock_items = InventoryItem.query.filter(
                InventoryItem.quantity <= InventoryItem.reorder_level
            ).all()
            
            if low_stock_items:
                items_list = ", ".join([f"{item.name} ({item.quantity} units)" for item in low_stock_items[:5]])
                reply = f"Low stock items: {items_list}"
                if len(low_stock_items) > 5:
                    reply += f" and {len(low_stock_items) - 5} more."
            else:
                reply = "No items are currently low in stock."
        
        elif 'help' in message:
            reply = "I can help you with: stock levels, sales information, low stock alerts, and inventory queries. Try asking about specific items or general inventory status."
        
        else:
            reply = "I can help you with inventory queries. Ask me about stock levels, sales, or low stock items."
        
        # Save chat message
        chat_message = ChatMessage(
            user_id=session.get('user_id'),
            message=message,
            response=reply
        )
        db.session.add(chat_message)
        db.session.commit()
        
        return jsonify({'reply': reply})
        
    except Exception as e:
        return jsonify({'reply': f'Error processing request: {str(e)}'})

# API endpoints for data visualization
@app.route('/api/inventory/stats')
@login_required
def inventory_stats():
    """Get inventory statistics for dashboard"""
    try:
        # Category distribution
        category_stats = db.session.query(
            InventoryItem.category,
            func.count(InventoryItem.id).label('count'),
            func.sum(InventoryItem.quantity).label('total_quantity')
        ).group_by(InventoryItem.category).all()
        
        # Low stock items
        low_stock_items = InventoryItem.query.filter(
            InventoryItem.quantity <= InventoryItem.reorder_level
        ).all()
        
        # Recent sales data
        recent_sales = db.session.query(
            func.date(SalesRecord.sale_date).label('date'),
            func.sum(SalesRecord.quantity_sold).label('total_sold'),
            func.sum(SalesRecord.sale_price * SalesRecord.quantity_sold).label('total_revenue')
        ).group_by(func.date(SalesRecord.sale_date)).order_by(desc('date')).limit(30).all()
        
        return jsonify({
            'category_stats': [{'category': cat, 'count': count, 'total_quantity': int(qty)} 
                             for cat, count, qty in category_stats],
            'low_stock_items': [item.to_dict() for item in low_stock_items],
            'recent_sales': [{'date': str(date), 'total_sold': int(sold), 'total_revenue': float(revenue)} 
                           for date, sold, revenue in recent_sales]
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Error handlers
@app.errorhandler(404)
def not_found(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('500.html'), 500

# API endpoints for React frontend
@app.route('/api/auth/login', methods=['POST'])
def api_login():
    """API login endpoint"""
    data = request.get_json()
    
    if not data or not data.get('email') or not data.get('password'):
        return jsonify({'message': 'Email and password are required'}), 400
    
    user = User.query.filter_by(email=data['email']).first()
    
    if user and user.check_password(data['password']):
        access_token = create_access_token(identity=user.id)
        return jsonify({
            'token': access_token,
            'user': {
                'id': user.id,
                'email': user.email,
                'first_name': user.first_name,
                'last_name': user.last_name
            }
        })
    else:
        return jsonify({'message': 'Invalid credentials'}), 401

@app.route('/api/auth/register', methods=['POST'])
def api_register():
    """API registration endpoint"""
    data = request.get_json()
    
    if not data or not data.get('email') or not data.get('password'):
        return jsonify({'message': 'Email and password are required'}), 400
    
    if User.query.filter_by(email=data['email']).first():
        return jsonify({'message': 'Email already exists'}), 400
    
    user = User(
        email=data['email'],
        first_name=data.get('first_name', ''),
        last_name=data.get('last_name', '')
    )
    user.set_password(data['password'])
    
    db.session.add(user)
    db.session.commit()
    
    return jsonify({'message': 'Registration successful'}), 201

@app.route('/api/auth/me', methods=['GET'])
@jwt_required()
def api_me():
    """Get current user info"""
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({'message': 'User not found'}), 404
    
    return jsonify({
        'id': user.id,
        'email': user.email,
        'first_name': user.first_name,
        'last_name': user.last_name
    })

@app.route('/api/inventory', methods=['GET'])
@jwt_required()
def api_inventory():
    """Get all inventory items"""
    items = InventoryItem.query.all()
    return jsonify([item.to_dict() for item in items])

@app.route('/api/inventory', methods=['POST'])
@jwt_required()
def api_add_inventory():
    """Add new inventory item"""
    data = request.get_json()
    
    if not data or not data.get('name') or not data.get('sku'):
        return jsonify({'message': 'Name and SKU are required'}), 400
    
    if InventoryItem.query.filter_by(sku=data['sku']).first():
        return jsonify({'message': 'SKU already exists'}), 400
    
    item = InventoryItem(
        name=data['name'],
        sku=data['sku'],
        description=data.get('description', ''),
        category=data.get('category', ''),
        quantity=data.get('quantity', 0),
        unit_price=data.get('unit_price', 0),
        reorder_level=data.get('reorder_level', 10),
        supplier=data.get('supplier', '')
    )
    
    db.session.add(item)
    db.session.commit()
    
    return jsonify(item.to_dict()), 201

@app.route('/api/inventory/<int:item_id>', methods=['PUT'])
@jwt_required()
def api_update_inventory(item_id):
    """Update inventory item"""
    item = InventoryItem.query.get_or_404(item_id)
    data = request.get_json()
    
    if not data:
        return jsonify({'message': 'No data provided'}), 400
    
    item.name = data.get('name', item.name)
    item.description = data.get('description', item.description)
    item.category = data.get('category', item.category)
    item.quantity = data.get('quantity', item.quantity)
    item.unit_price = data.get('unit_price', item.unit_price)
    item.reorder_level = data.get('reorder_level', item.reorder_level)
    item.supplier = data.get('supplier', item.supplier)
    
    db.session.commit()
    
    return jsonify(item.to_dict())

@app.route('/api/inventory/<int:item_id>', methods=['DELETE'])
@jwt_required()
def api_delete_inventory(item_id):
    """Delete inventory item"""
    item = InventoryItem.query.get_or_404(item_id)
    
    db.session.delete(item)
    db.session.commit()
    
    return jsonify({'message': 'Item deleted successfully'})

@app.route('/api/inventory/stats', methods=['GET'])
@jwt_required()
def api_inventory_stats():
    """Get inventory statistics"""
    # Category stats
    category_stats = db.session.query(
        InventoryItem.category,
        func.count(InventoryItem.id).label('count')
    ).group_by(InventoryItem.category).all()
    
    category_data = [{'category': cat or 'Uncategorized', 'count': count} for cat, count in category_stats]
    
    # Low stock items
    low_stock_items = InventoryItem.query.filter(
        InventoryItem.quantity <= InventoryItem.reorder_level
    ).all()
    
    # Recent sales (mock data for now)
    recent_sales = [
        {'date': '2025-01-15', 'total_sold': 25, 'total_revenue': 750.00},
        {'date': '2025-01-14', 'total_sold': 18, 'total_revenue': 540.00},
        {'date': '2025-01-13', 'total_sold': 32, 'total_revenue': 960.00},
        {'date': '2025-01-12', 'total_sold': 22, 'total_revenue': 660.00},
        {'date': '2025-01-11', 'total_sold': 28, 'total_revenue': 840.00},
    ]
    
    return jsonify({
        'category_stats': category_data,
        'low_stock_items': [item.to_dict() for item in low_stock_items],
        'recent_sales': recent_sales
    })

@app.route('/api/upload-sales', methods=['POST'])
@jwt_required()
def api_upload_sales():
    """Upload sales data via CSV"""
    if 'file' not in request.files:
        return jsonify({'message': 'No file provided'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'message': 'No file selected'}), 400
    
    if not file.filename.endswith('.csv'):
        return jsonify({'message': 'Only CSV files are allowed'}), 400
    
    try:
        # Read CSV data
        df = pd.read_csv(file)
        
        # Validate required columns
        required_columns = ['sku', 'quantity_sold', 'sale_price', 'sale_date']
        missing_columns = [col for col in required_columns if col not in df.columns]
        
        if missing_columns:
            return jsonify({
                'message': f'Missing required columns: {", ".join(missing_columns)}'
            }), 400
        
        processed_records = 0
        errors = []
        
        for index, row in df.iterrows():
            try:
                # Find inventory item by SKU
                item = InventoryItem.query.filter_by(sku=row['sku']).first()
                if not item:
                    errors.append(f'Row {index + 1}: SKU "{row["sku"]}" not found')
                    continue
                
                # Parse date
                try:
                    sale_date = pd.to_datetime(row['sale_date']).date()
                except:
                    errors.append(f'Row {index + 1}: Invalid date format')
                    continue
                
                # Create sales record
                sales_record = SalesRecord(
                    item_id=item.id,
                    quantity_sold=int(row['quantity_sold']),
                    sale_price=float(row['sale_price']),
                    sale_date=sale_date,
                    customer_name=row.get('customer_name', ''),
                    notes=row.get('notes', '')
                )
                
                db.session.add(sales_record)
                processed_records += 1
                
            except Exception as e:
                errors.append(f'Row {index + 1}: {str(e)}')
        
        db.session.commit()
        
        return jsonify({
            'message': f'Successfully processed {processed_records} records',
            'processed_records': processed_records,
            'errors': errors
        })
        
    except Exception as e:
        return jsonify({'message': f'Error processing file: {str(e)}'}), 500

@app.route('/api/chat', methods=['POST'])
@jwt_required()
def api_chat():
    """Chat with AI assistant"""
    data = request.get_json()
    
    if not data or not data.get('message'):
        return jsonify({'message': 'Message is required'}), 400
    
    user_id = get_jwt_identity()
    user_message = data['message']
    
    # Simple AI response logic (you can replace with actual AI)
    response = generate_ai_response(user_message)
    
    # Store chat message
    chat_message = ChatMessage(
        user_id=user_id,
        message=user_message,
        response=response
    )
    
    db.session.add(chat_message)
    db.session.commit()
    
    return jsonify({'reply': response})

def generate_ai_response(message):
    """Generate AI response based on user message"""
    message_lower = message.lower()
    
    if 'stock' in message_lower or 'inventory' in message_lower:
        total_items = InventoryItem.query.count()
        low_stock_count = InventoryItem.query.filter(
            InventoryItem.quantity <= InventoryItem.reorder_level
        ).count()
        
        return f"You currently have {total_items} items in inventory. {low_stock_count} items are at or below reorder level and need restocking."
    
    elif 'low stock' in message_lower or 'reorder' in message_lower:
        low_stock_items = InventoryItem.query.filter(
            InventoryItem.quantity <= InventoryItem.reorder_level
        ).limit(5).all()
        
        if not low_stock_items:
            return "Great news! No items are currently low in stock."
        
        item_names = [item.name for item in low_stock_items]
        return f"The following items are low in stock: {', '.join(item_names)}. Consider reordering these items soon."
    
    elif 'sales' in message_lower or 'revenue' in message_lower:
        return "Your sales data shows steady performance. Recent trends indicate good inventory turnover with consistent revenue generation."
    
    elif 'help' in message_lower:
        return "I can help you with:\n• Stock level inquiries\n• Low stock alerts\n• Sales data analysis\n• Inventory recommendations\n• General inventory questions\n\nJust ask me anything about your inventory!"
    
    else:
        return "I'm here to help with your inventory management. You can ask me about stock levels, low stock items, sales data, or get general inventory assistance. What would you like to know?"
