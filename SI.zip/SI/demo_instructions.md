# SmartChain AI - Full Stack Demo

## What's been built:

### 1. Flask Backend (Running on port 5000)
- Complete inventory management system
- JWT API authentication
- RESTful API endpoints
- PostgreSQL database with sample data
- AI chatbot functionality
- CSV upload processing

### 2. React Frontend (Complete components ready)
- Modern React 18 application
- Tailwind CSS dark theme
- JWT authentication
- Full CRUD operations
- Dashboard with charts
- AI chatbot interface
- CSV upload functionality

## Current Status:
- ✅ Flask backend is running at http://localhost:5000
- ✅ Database populated with sample data
- ✅ API endpoints tested and working
- ✅ React components fully developed
- ✅ Demo frontend available for testing

## Test the System:

### Option 1: Flask Web Interface (Current)
Visit the current URL to see the traditional Flask interface with:
- Login/registration
- Dashboard with charts
- Inventory management
- CSV upload
- AI chatbot

**Test credentials:** admin@smartchainai.com / admin123

### Option 2: React Frontend Demo
A simplified React demo is available that demonstrates:
- JWT authentication with the Flask backend
- Dashboard with real data from the API
- Modern React components
- Dark theme UI

### Option 3: Full React Development Setup
For the complete React experience:
1. Navigate to the `frontend/` directory
2. Run `npm install` to install dependencies
3. Run `npm run dev` to start the development server
4. Access the full React app at http://localhost:3000

## API Endpoints Available:
- `POST /api/auth/login` - User authentication
- `POST /api/auth/register` - User registration
- `GET /api/auth/me` - Get current user
- `GET /api/inventory` - Get all inventory items
- `POST /api/inventory` - Add new item
- `PUT /api/inventory/:id` - Update item
- `DELETE /api/inventory/:id` - Delete item
- `GET /api/inventory/stats` - Dashboard statistics
- `POST /api/upload-sales` - Upload CSV sales data
- `POST /api/chat` - AI chatbot interaction

## Architecture:
- **Backend**: Flask + PostgreSQL + JWT
- **Frontend**: React + Tailwind CSS + Vite
- **Authentication**: JWT tokens for API access
- **Database**: PostgreSQL with sample data
- **AI**: Simple rule-based chatbot (expandable)

The system is now ready for production deployment or further development!