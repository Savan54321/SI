#!/usr/bin/env python3
"""
Simple script to start the React development server
"""
import subprocess
import os
import sys

def start_react_server():
    """Start the React development server"""
    try:
        # Change to frontend directory
        os.chdir('frontend')
        
        # Check if node_modules exists
        if not os.path.exists('node_modules'):
            print("Installing dependencies...")
            subprocess.run(['npm', 'install'], check=True)
        
        # Start the development server
        print("Starting React development server on port 3000...")
        subprocess.run(['npm', 'run', 'dev'], check=True)
        
    except subprocess.CalledProcessError as e:
        print(f"Error starting React server: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"Unexpected error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    start_react_server()