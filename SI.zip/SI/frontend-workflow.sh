#!/bin/bash
cd frontend
npm run dev