#!/usr/bin/env python3
"""
Simple HTTP server to serve the React frontend for testing
"""
import os
import sys
import http.server
import socketserver
from pathlib import Path

def create_index_html():
    """Create a simple index.html for testing the React components"""
    html_content = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartChain AI - React Frontend</title>
    <script src="https://unpkg.com/react@18/umd/react.development.js"></script>
    <script src="https://unpkg.com/react-dom@18/umd/react-dom.development.js"></script>
    <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
    <script src="https://unpkg.com/lucide-react/dist/esm/index.js"></script>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
                'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
                sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            background-color: #111827;
            color: #ffffff;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }
        
        .card {
            background-color: #1f2937;
            border: 1px solid #374151;
            border-radius: 0.5rem;
            padding: 1.5rem;
            margin-bottom: 1rem;
        }
        
        .btn {
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 0.375rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .btn-primary {
            background-color: #3b82f6;
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #2563eb;
        }
        
        .input {
            width: 100%;
            padding: 0.75rem;
            background-color: #374151;
            border: 1px solid #4b5563;
            border-radius: 0.375rem;
            color: white;
            margin-bottom: 1rem;
        }
        
        .input:focus {
            outline: none;
            border-color: #3b82f6;
        }
        
        .grid {
            display: grid;
            gap: 1rem;
        }
        
        .grid-cols-2 {
            grid-template-columns: repeat(2, 1fr);
        }
        
        .text-center {
            text-align: center;
        }
        
        .text-sm {
            font-size: 0.875rem;
        }
        
        .text-gray-400 {
            color: #9ca3af;
        }
        
        .mb-4 {
            margin-bottom: 1rem;
        }
        
        .mt-6 {
            margin-top: 1.5rem;
        }
        
        .flex {
            display: flex;
        }
        
        .items-center {
            align-items: center;
        }
        
        .justify-center {
            justify-content: center;
        }
        
        .gap-2 {
            gap: 0.5rem;
        }
        
        .min-h-screen {
            min-height: 100vh;
        }
    </style>
</head>
<body>
    <div id="root"></div>
    
    <script type="text/babel">
        const { useState, useEffect } = React;
        
        // Simple Login Component
        function Login({ onLogin }) {
            const [email, setEmail] = useState('admin@smartchainai.com');
            const [password, setPassword] = useState('admin123');
            const [loading, setLoading] = useState(false);
            const [error, setError] = useState('');
            
            const handleSubmit = async (e) => {
                e.preventDefault();
                setLoading(true);
                setError('');
                
                try {
                    const response = await axios.post('http://localhost:5000/api/auth/login', {
                        email,
                        password
                    });
                    
                    localStorage.setItem('token', response.data.token);
                    onLogin(response.data.user);
                } catch (error) {
                    setError(error.response?.data?.message || 'Login failed');
                } finally {
                    setLoading(false);
                }
            };
            
            return (
                <div className="min-h-screen flex items-center justify-center">
                    <div className="card" style={{maxWidth: '400px', width: '100%'}}>
                        <div className="text-center mb-4">
                            <h2 style={{fontSize: '1.5rem', fontWeight: 'bold', marginBottom: '0.5rem'}}>
                                SmartChain AI
                            </h2>
                            <p className="text-gray-400">Sign in to your account</p>
                        </div>
                        
                        <form onSubmit={handleSubmit}>
                            <input
                                type="email"
                                placeholder="Email"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                className="input"
                                required
                            />
                            <input
                                type="password"
                                placeholder="Password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                className="input"
                                required
                            />
                            
                            {error && (
                                <div style={{color: '#ef4444', fontSize: '0.875rem', marginBottom: '1rem'}}>
                                    {error}
                                </div>
                            )}
                            
                            <button
                                type="submit"
                                disabled={loading}
                                className="btn btn-primary"
                                style={{width: '100%'}}
                            >
                                {loading ? 'Signing in...' : 'Sign In'}
                            </button>
                        </form>
                        
                        <div className="text-center mt-6">
                            <p className="text-sm text-gray-400">
                                Test credentials: admin@smartchainai.com / admin123
                            </p>
                        </div>
                    </div>
                </div>
            );
        }
        
        // Simple Dashboard Component
        function Dashboard({ user }) {
            const [stats, setStats] = useState({});
            const [loading, setLoading] = useState(true);
            
            useEffect(() => {
                loadStats();
            }, []);
            
            const loadStats = async () => {
                try {
                    const token = localStorage.getItem('token');
                    const response = await axios.get('http://localhost:5000/api/inventory/stats', {
                        headers: { Authorization: `Bearer ${token}` }
                    });
                    setStats(response.data);
                } catch (error) {
                    console.error('Error loading stats:', error);
                } finally {
                    setLoading(false);
                }
            };
            
            if (loading) {
                return <div className="container">Loading...</div>;
            }
            
            return (
                <div className="container">
                    <div className="flex items-center justify-between mb-4">
                        <h1 style={{fontSize: '2rem', fontWeight: 'bold'}}>Dashboard</h1>
                        <div className="flex items-center gap-2">
                            <span>Welcome, {user.email}</span>
                            <button 
                                onClick={() => {
                                    localStorage.removeItem('token');
                                    window.location.reload();
                                }}
                                className="btn btn-primary"
                            >
                                Logout
                            </button>
                        </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 mb-4">
                        <div className="card">
                            <h3 style={{fontSize: '1.125rem', fontWeight: '600', marginBottom: '0.5rem'}}>
                                Total Items
                            </h3>
                            <p style={{fontSize: '1.5rem', fontWeight: 'bold'}}>
                                {stats.category_stats?.reduce((sum, cat) => sum + cat.count, 0) || 0}
                            </p>
                        </div>
                        
                        <div className="card">
                            <h3 style={{fontSize: '1.125rem', fontWeight: '600', marginBottom: '0.5rem'}}>
                                Low Stock Items
                            </h3>
                            <p style={{fontSize: '1.5rem', fontWeight: 'bold'}}>
                                {stats.low_stock_items?.length || 0}
                            </p>
                        </div>
                    </div>
                    
                    <div className="card">
                        <h3 style={{fontSize: '1.125rem', fontWeight: '600', marginBottom: '1rem'}}>
                            API Endpoints Available
                        </h3>
                        <ul style={{listStyle: 'disc', paddingLeft: '1.5rem'}}>
                            <li>GET /api/inventory - Get all inventory items</li>
                            <li>POST /api/inventory - Add new item</li>
                            <li>PUT /api/inventory/:id - Update item</li>
                            <li>DELETE /api/inventory/:id - Delete item</li>
                            <li>GET /api/inventory/stats - Get statistics</li>
                            <li>POST /api/upload-sales - Upload sales data</li>
                            <li>POST /api/chat - Chat with AI assistant</li>
                        </ul>
                    </div>
                    
                    <div className="card">
                        <h3 style={{fontSize: '1.125rem', fontWeight: '600', marginBottom: '1rem'}}>
                            Next Steps
                        </h3>
                        <p>To fully test the React frontend:</p>
                        <ol style={{listStyle: 'decimal', paddingLeft: '1.5rem', marginTop: '0.5rem'}}>
                            <li>The complete React app is in the <code>/frontend</code> directory</li>
                            <li>Run <code>npm install</code> and <code>npm run dev</code> in the frontend directory</li>
                            <li>The app will be available at <code>http://localhost:3000</code></li>
                            <li>It includes full inventory management, dashboard, upload, and chatbot features</li>
                        </ol>
                    </div>
                </div>
            );
        }
        
        // Main App Component
        function App() {
            const [user, setUser] = useState(null);
            const [loading, setLoading] = useState(true);
            
            useEffect(() => {
                checkAuth();
            }, []);
            
            const checkAuth = async () => {
                try {
                    const token = localStorage.getItem('token');
                    if (token) {
                        const response = await axios.get('http://localhost:5000/api/auth/me', {
                            headers: { Authorization: `Bearer ${token}` }
                        });
                        setUser(response.data);
                    }
                } catch (error) {
                    localStorage.removeItem('token');
                } finally {
                    setLoading(false);
                }
            };
            
            if (loading) {
                return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
            }
            
            return user ? <Dashboard user={user} /> : <Login onLogin={setUser} />;
        }
        
        // Render the app
        ReactDOM.render(<App />, document.getElementById('root'));
    </script>
</body>
</html>"""
    
    return html_content

def start_server():
    """Start a simple HTTP server to serve the React frontend"""
    # Create the frontend directory if it doesn't exist
    os.makedirs('frontend_demo', exist_ok=True)
    
    # Create the index.html file
    with open('frontend_demo/index.html', 'w') as f:
        f.write(create_index_html())
    
    # Change to the frontend directory
    os.chdir('frontend_demo')
    
    # Start the server
    PORT = 3000
    Handler = http.server.SimpleHTTPRequestHandler
    
    with socketserver.TCPServer(("", PORT), Handler) as httpd:
        print(f"React Frontend Demo running at http://localhost:{PORT}")
        print("Press Ctrl+C to stop the server")
        httpd.serve_forever()

if __name__ == "__main__":
    start_server()