# Deployment Guide - SmartChain AI

This guide covers different deployment options for the SmartChain AI inventory management system.

## 🚀 Quick Start

### Local Development
```bash
# Backend
python main.py

# Frontend (separate terminal)
cd frontend
npm run dev
```

## 🐳 Docker Deployment

### Using Docker Compose (Recommended)
```yaml
# docker-compose.yml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "5000:5000"
    environment:
      - DATABASE_URL=postgresql://postgres:password@db:5432/smartchain
      - SESSION_SECRET=your-session-secret
      - JWT_SECRET=your-jwt-secret
    depends_on:
      - db

  db:
    image: postgres:15
    environment:
      - POSTGRES_DB=smartchain
      - POSTGRES_USER=postgres
      - POSTGRES_PASSWORD=password
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"

  frontend:
    build: ./frontend
    ports:
      - "3000:3000"
    depends_on:
      - app

volumes:
  postgres_data:
```

### Single Container Build
```bash
# Build the image
docker build -t smartchain-ai .

# Run with environment variables
docker run -d \
  -p 5000:5000 \
  -e DATABASE_URL="your-database-url" \
  -e SESSION_SECRET="your-session-secret" \
  -e JWT_SECRET="your-jwt-secret" \
  smartchain-ai
```

## ☁️ Cloud Deployment

### Heroku
```bash
# Install Heroku CLI
# Create app
heroku create smartchain-ai

# Add PostgreSQL addon
heroku addons:create heroku-postgresql:hobby-dev

# Set environment variables
heroku config:set SESSION_SECRET=your-session-secret
heroku config:set JWT_SECRET=your-jwt-secret

# Deploy
git push heroku main
```

### AWS EC2
```bash
# Launch Ubuntu instance
# Install dependencies
sudo apt update
sudo apt install python3-pip nodejs npm postgresql

# Clone repository
git clone https://github.com/Savan54321/SmartChainIntelligence.git
cd SmartChainIntelligence

# Setup backend
pip3 install -r requirements.txt
python3 seed_data.py

# Setup frontend
cd frontend
npm install
npm run build

# Start with PM2
npm install -g pm2
pm2 start ecosystem.config.js
```

### Digital Ocean
```bash
# Create droplet
# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh

# Clone and deploy
git clone https://github.com/Savan54321/SmartChainIntelligence.git
cd SmartChainIntelligence
docker-compose up -d
```

## 🔧 Production Configuration

### Environment Variables
```bash
# Required
DATABASE_URL=postgresql://user:pass@host:5432/dbname
SESSION_SECRET=your-complex-session-secret
JWT_SECRET=your-complex-jwt-secret

# Optional
FLASK_ENV=production
FLASK_DEBUG=false
GUNICORN_WORKERS=4
GUNICORN_TIMEOUT=30
```

### Nginx Configuration
```nginx
# /etc/nginx/sites-available/smartchain-ai
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /static {
        alias /path/to/smartchain/static;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

### SSL with Let's Encrypt
```bash
# Install certbot
sudo apt install certbot python3-certbot-nginx

# Get certificate
sudo certbot --nginx -d your-domain.com

# Auto-renewal
sudo crontab -e
0 12 * * * /usr/bin/certbot renew --quiet
```

## 📊 Database Setup

### PostgreSQL Production
```sql
-- Create database
CREATE DATABASE smartchain_production;

-- Create user
CREATE USER smartchain_user WITH ENCRYPTED PASSWORD 'secure_password';

-- Grant privileges
GRANT ALL PRIVILEGES ON DATABASE smartchain_production TO smartchain_user;
```

### Migration Commands
```bash
# Initialize database
python seed_data.py

# Backup database
pg_dump smartchain_production > backup.sql

# Restore database
psql smartchain_production < backup.sql
```

## 🔍 Monitoring & Logging

### Application Monitoring
```python
# Add to app.py
import logging
from logging.handlers import RotatingFileHandler

if not app.debug:
    file_handler = RotatingFileHandler('logs/smartchain.log', maxBytes=10240, backupCount=10)
    file_handler.setFormatter(logging.Formatter(
        '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
    ))
    file_handler.setLevel(logging.INFO)
    app.logger.addHandler(file_handler)
```

### System Monitoring
```bash
# Install monitoring tools
sudo apt install htop iotop

# Monitor logs
tail -f logs/smartchain.log
tail -f /var/log/nginx/error.log
```

## 🛡️ Security Checklist

### Application Security
- [ ] Use HTTPS in production
- [ ] Set secure session cookies
- [ ] Implement rate limiting
- [ ] Validate all inputs
- [ ] Use strong secrets
- [ ] Regular security updates

### Database Security
- [ ] Use connection pooling
- [ ] Regular backups
- [ ] Restrict database access
- [ ] Use encrypted connections
- [ ] Monitor database logs

### Server Security
- [ ] Regular OS updates
- [ ] Firewall configuration
- [ ] SSH key authentication
- [ ] Regular security audits
- [ ] Log monitoring

## 🔄 CI/CD Pipeline

### GitHub Actions
```yaml
# .github/workflows/deploy.yml
name: Deploy to Production

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    
    - name: Setup Python
      uses: actions/setup-python@v2
      with:
        python-version: '3.9'
    
    - name: Install dependencies
      run: pip install -r requirements.txt
    
    - name: Run tests
      run: python -m pytest
    
    - name: Deploy to server
      run: |
        # Add deployment commands
```

## 📈 Performance Optimization

### Backend Optimization
- Use database connection pooling
- Implement caching (Redis)
- Optimize database queries
- Use Gunicorn with multiple workers
- Enable gzip compression

### Frontend Optimization
- Build optimized React bundle
- Use CDN for static assets
- Implement lazy loading
- Optimize images
- Enable browser caching

## 🆘 Troubleshooting

### Common Issues
1. **Database connection errors**
   - Check DATABASE_URL format
   - Verify database is running
   - Check network connectivity

2. **Authentication issues**
   - Verify SESSION_SECRET is set
   - Check JWT_SECRET configuration
   - Ensure consistent secrets across restarts

3. **Static file issues**
   - Check file permissions
   - Verify static file paths
   - Ensure proper Nginx configuration

### Debug Mode
```bash
# Enable debug mode
export FLASK_DEBUG=true
export FLASK_ENV=development
python main.py
```

## 📞 Support

For deployment issues:
- Check logs first
- Review this guide
- Create GitHub issue
- Contact support team

---

**SmartChain AI** - Deploy with confidence!