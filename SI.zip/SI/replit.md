# Inventory Management System

## Overview

This is a Flask-based inventory management system with AI-powered chat assistance. The application provides comprehensive inventory tracking, sales data management, and user authentication in a web-based interface.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Backend Architecture
- **Framework**: Flask with SQLAlchemy ORM
- **Database**: PostgreSQL with SQLAlchemy as the ORM layer
- **Authentication**: JWT-based authentication using Flask-JWT-Extended and session-based authentication for web interface
- **CORS**: Enabled for cross-origin requests
- **API Endpoints**: RESTful API for React frontend integration

### Frontend Architecture
- **Primary**: React 18 with Vite build tool
- **Routing**: React Router DOM for client-side routing
- **State Management**: React Context API for authentication
- **Styling**: Tailwind CSS with custom dark theme
- **Charts**: Recharts for data visualization
- **Icons**: Lucide React for consistent iconography
- **HTTP Client**: Axios for API requests

### Legacy Frontend (Maintained)
- **Template Engine**: Jinja2 templates with Bootstrap 5 dark theme
- **JavaScript**: Vanilla JavaScript with modular architecture
- **Styling**: Bootstrap 5 with custom CSS
- **Charts**: Chart.js for data visualization
- **Icons**: Feather icons for consistent iconography

### Data Layer
- **ORM**: SQLAlchemy with Flask-SQLAlchemy
- **Database**: PostgreSQL (configurable via DATABASE_URL environment variable)
- **Connection Pooling**: Built-in SQLAlchemy connection pooling with pre-ping enabled

## Key Components

### Models
- **User**: Handles user authentication with email/password, includes profile information
- **InventoryItem**: Core inventory management with SKU, quantities, pricing, and supplier information
- **SalesRecord**: Track sales transactions (referenced but not fully implemented)
- **ChatMessage**: Store AI assistant conversation history (referenced but not fully implemented)

### Routes and Views
- **Authentication Routes**: Login, registration, logout functionality
- **Dashboard**: Main overview with metrics and charts
- **Inventory Management**: CRUD operations for inventory items
- **File Upload**: CSV import functionality for sales data
- **AI Chatbot**: Interactive assistant for inventory queries

### Static Assets
- **CSS**: Custom styling with CSS variables and Bootstrap customization
- **JavaScript**: Modular JS files for different features (dashboard, inventory, chatbot)
- **Templates**: Responsive HTML templates with consistent navigation

## Data Flow

1. **User Authentication**: 
   - Session-based authentication for legacy web interface
   - JWT tokens for React frontend and API access
   - Unified authentication system supporting both approaches
2. **Inventory Operations**: CRUD operations through web forms and RESTful API endpoints
3. **Data Import**: CSV file upload processing for bulk sales data import
4. **AI Assistant**: Chat interface for natural language inventory queries
5. **Dashboard Analytics**: Real-time metrics and visualizations
6. **React Frontend**: Modern SPA with API-driven data management

## External Dependencies

### Python Packages
- **Flask**: Web framework
- **Flask-SQLAlchemy**: Database ORM
- **Flask-JWT-Extended**: JWT authentication
- **Flask-CORS**: Cross-origin resource sharing
- **pandas**: Data processing for CSV imports
- **psycopg2-binary**: PostgreSQL database adapter
- **Werkzeug**: WSGI utilities and password hashing

### Frontend Libraries
#### React Frontend
- **React 18**: Modern component-based UI library
- **Vite**: Fast build tool and development server
- **React Router DOM**: Client-side routing
- **Tailwind CSS**: Utility-first CSS framework
- **Recharts**: React charting library
- **Lucide React**: Icon library
- **Axios**: HTTP client for API requests

#### Legacy Frontend
- **Bootstrap 5**: UI framework with dark theme
- **Chart.js**: Data visualization
- **Feather Icons**: Icon library
- **Vanilla JavaScript**: No additional frontend frameworks

## Deployment Strategy

### Environment Configuration
- **Database**: PostgreSQL connection via DATABASE_URL environment variable
- **Security**: JWT_SECRET and SESSION_SECRET for authentication
- **WSGI**: ProxyFix middleware for proper proxy handling
- **Logging**: Debug logging enabled for development

### Production Considerations
- Database connection pooling with pre-ping for reliability
- CORS configuration for API access
- Session management for web interface
- Environment-based configuration for secrets

### Development Setup
- Flask development server with hot reload
- Debug mode enabled
- Automatic database table creation
- Static file serving for CSS/JS assets

The application follows a traditional MVC pattern with clear separation between data models, business logic in routes, and presentation in templates. The dual authentication system (session + JWT) allows for both web interface usage and API access.